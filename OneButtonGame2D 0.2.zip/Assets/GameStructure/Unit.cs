﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets.GameStructure
{
    public enum UnitType
    {
        empty,
        fireElement,//1
        waterElement,
        electricityElement
    }

    class Unit
    {
        public ArmorType body;
        public AttackType attack;
        public GameObject gameObject;

        public Unit(ArmorType body, AttackType attack, GameObject gameObject)
        {
        }
        public Unit()
        {
        }
    }

    class Team
    {
        public ArrayList units = new ArrayList();

        public Team()
        {

        }
        
        public void update(float time)
        {
            foreach (Unit unit in units)
            {
                unit.gameObject.transform.Translate(new Vector3(time, 0,0));
            }
        }
    }
}
