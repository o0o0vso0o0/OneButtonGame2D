﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monsters : MonoBehaviour {
    static float frameTime = 0.016f;


    Assets.Team friendlyTeam = new Assets.Team();

    // Use this for initialization
    void Start () {
    }

    // Update is called once per frame
    void Update()
    {
        friendlyTeam.update(frameTime/2);

        /*if (Input.GetKeyDown(KeyCode.Space)
            || Input.GetKeyDown(KeyCode.Mouse0))
        {
            summon();
        }/**/
    }

    public void summon(float power)
    {
        Assets.Unit newUnit = new Assets.Unit();
        newUnit.gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        newUnit.gameObject.transform.parent = gameObject.transform;
        newUnit.gameObject.transform.localPosition = new Vector3(0, 0, 0);
        newUnit.gameObject.transform.localScale = new Vector3(power, power, power);
        friendlyTeam.units.Add(newUnit);
    }
}
