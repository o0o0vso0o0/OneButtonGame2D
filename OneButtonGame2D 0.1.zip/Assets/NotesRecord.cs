﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NotesRecord : MonoBehaviour {

    GameObject notesRecordPanel;
    ArrayList notes = new ArrayList();
    int frameCountSinceAdd = 0;

	// Use this for initialization
	void Start () {
        notesRecordPanel = new GameObject("notesRecordPanel");
        notesRecordPanel.transform.localPosition = new Vector3(-7, -2, 0);
    }
	
	// Update is called once per frame
	void Update () {
        if (frameCountSinceAdd>100)
        {
            summon();
            frameCountSinceAdd = 0;
        }

        frameCountSinceAdd++;
    }

    public void addNote(GameObject note)
    {
        note.transform.parent = notesRecordPanel.transform;
        note.transform.localPosition = new Vector3(notes.Count, 0, 0);
        note.transform.localRotation = new Quaternion(0,0,0,0);
        notes.Add(note);

        frameCountSinceAdd = 0;
    }
    public void summon()
    {
        if (notes.Count == 0)
            return;

        foreach (GameObject i in notes)
        {
            Destroy(i);
        }
        gameObject.GetComponent<Monsters>().summon(0.5f + notes.Count*0.1f);
        notes.Clear();
    }
}
