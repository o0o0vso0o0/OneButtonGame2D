﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace Assets
{
    class Unit
    {
        float HP;
        float attack;
        float defense;
        public GameObject gameObject;

        public Unit(GameObject gameObject)
        {
            this.gameObject = gameObject;
        }

        public Unit()
        {
        }
    }

    class Team
    {
        public ArrayList units = new ArrayList();

        public Team()
        {

        }
        
        public void update(float time)
        {
            foreach (Unit unit in units)
            {
                unit.gameObject.transform.Translate(new Vector3(time, 0,0));
            }
        }
    }
}
